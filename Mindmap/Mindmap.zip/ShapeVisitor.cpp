#include "ShapeVisitor.h"
#include "Topic.h"
#include "Line.h"
#include "Branch.h"

ShapeVisitor::ShapeVisitor() {

}

ShapeVisitor::~ShapeVisitor() {

}
void ShapeVisitor::VisitTopic(Topic *topic) {

}
void ShapeVisitor::VisitLine(Line *line) {

}

void ShapeVisitor::VisitBranch(Branch * branch)
{

}
