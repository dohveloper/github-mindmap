//TextVisitor.cpp

#include "TextVisitor.h"

TextVisitor::TextVisitor() {

}

TextVisitor::~TextVisitor() {

}

void TextVisitor::VisitText(Text *text) {

}

void TextVisitor::VisitRow(Row *row) {

}
void TextVisitor::VisitSingleByteCharacter(SingleByteCharacter *singleByteCharacter) {

}
void TextVisitor::VisitDoubleByteCharacter(DoubleByteCharacter *doubleByteCharacter) {

}