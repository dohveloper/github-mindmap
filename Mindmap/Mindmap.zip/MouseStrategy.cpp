#include "MouseStrategy.h"
#include "Selection.h"


MouseStrategy::MouseStrategy() {

}
MouseStrategy::~MouseStrategy() {

}
void MouseStrategy::OnLButtonDown(CPoint point, UINT flags, Selection *selection, Branch *branch) {

}
void MouseStrategy::OnMouseMove(CPoint point) {

}
void MouseStrategy::OnLButtonUp(Selection *selection, bool isOverlapped) {

}
