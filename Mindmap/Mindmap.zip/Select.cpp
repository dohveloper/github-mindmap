//Select.cpp

#include "Select.h"
#include "Branch.h"
#include "Selection.h"

Select::Select()
{
}

Select::Select(const Select& source)
{

}

Select::~Select()
{
}

void Select::SelectBranch(Selection *selection, Branch *branch)
{
}


Select& Select::operator=(const Select& source)
{
	return *this;
}

