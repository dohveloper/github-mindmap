//PAGEAPP.H

#ifndef _PAGEAPP_H
#define _PAGEAPP_H
#include <afxwin.h>

class PageApp : public CWinApp
{
public:
	virtual BOOL InitInstance();
};

#endif //_PAGEAPP_H