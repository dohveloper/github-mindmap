﻿#include "Iterator.h"

Iterator::Iterator() {

}